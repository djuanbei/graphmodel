#include "io/uppaaldata.h"
#include <string>

using namespace graphsat;

using std::string;

extern void parseProblem( const string &str, UppaalData * );

int main() {
  string str = "typedef int[1,4] id_t;\nint id;";
  //  string str="int id;";
  UppaalData data;
  parseProblem( str, &data );
  return 0;
}
