#!/bin/bash
lex -o uppaalscan.h uppaalscan.l
yacc -o uppaalparser.cpp -v uppaalparser.y
g++ -I ../include  -g *.cpp
